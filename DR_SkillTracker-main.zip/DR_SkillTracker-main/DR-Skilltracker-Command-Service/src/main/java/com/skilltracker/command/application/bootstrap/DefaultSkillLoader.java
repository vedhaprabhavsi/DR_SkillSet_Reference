package com.skilltracker.command.application.bootstrap;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.skilltracker.command.domain.model.Skillset;
import com.skilltracker.command.domain.service.DbSequenceGenarator;
import com.skilltracker.command.infrasturcture.repository.SkillsetRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DefaultSkillLoader implements CommandLineRunner {

    private static final String[] technicalSkillsetArray = { "HTML-CSS-JAVASCRIPT", "ANGULAR", "REACT", "SPRING", "RESTFUL", "HIBERNATE", "GIT", "DOCKER", "JENKINS", "AWS" };

    private static final String[] nonTechnicalSkillsetArray = { "SPOKEN", "COMMUNICATION", "APTITUDE" };

    @Autowired
    private SkillsetRepository skillsetRepository;

    @Autowired
    private DbSequenceGenarator sequenceGenr;

    // will be invoked automatically on the application startup
    @Override
    public void run(String... args) {

	if (skillsetRepository != null && CollectionUtils.isEmpty(skillsetRepository.findAll())) {
	    log.info("Saving default employees in the collection");
	    for (String skill : technicalSkillsetArray) {
		persist(skill, "Technical");
	    }
	    for (String skill : nonTechnicalSkillsetArray) {
		persist(skill, "NonTechnical");
	    }

	} else {
	    log.info("Default Skillsets are already present in the SkillSet mongo collection. Hence default skillset loader process skipped");
	}

    }

    // calls the service layer method which in turn calls the dao layer method
    // to save the employee record in the mongodb collection
    private void persist(String skillname, String skillType) {
	final Skillset e = createSkillset(skillname, skillType);
	skillsetRepository.save(e);
    }

    // using the faker library to create some mock data for the employee model
    private Skillset createSkillset(String skillName, String skillType) {

	return Skillset.builder().id(sequenceGenr.getNextSequence(Skillset.SEQUENCE_NUMBER)).skillName(skillName).skillType(skillType).createdDate(LocalDateTime.now().toString())
		.updatedDate(LocalDateTime.now().toString()).createdBy("SYSTEM").updatedBy("SYSTEM").build();
    }

}
