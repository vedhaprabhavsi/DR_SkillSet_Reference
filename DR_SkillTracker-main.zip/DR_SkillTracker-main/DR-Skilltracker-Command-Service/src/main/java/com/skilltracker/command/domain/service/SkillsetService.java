package com.skilltracker.command.domain.service;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.skilltracker.command.application.dto.CreateSkillsetRequest;
import com.skilltracker.command.domain.converter.SkillsetConverter;
import com.skilltracker.command.domain.model.Skillset;
import com.skilltracker.command.infrasturcture.eventsourcing.events.SkillsetCreatedEvent;
import com.skilltracker.command.infrasturcture.repository.SkillsetRepository;

import lombok.val;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class SkillsetService {

    @Autowired
    private SkillsetConverter skillsetConverter;

    @Autowired
    private SkillsetRepository skillsetRepository;

    public SkillsetCreatedEvent create(CreateSkillsetRequest request) {
	log.info("Creating new skillset");
	val skillset = skillsetConverter.creatSkillsetRequestRequestToSkillset(request);
	skillsetRepository.save(skillset);
	try {
	    return publicCreateSkillsetEvent(skillset);
	} catch (JsonProcessingException e) {
	    throw new RuntimeException(e);
	}
    }

    public SkillsetCreatedEvent publicCreateSkillsetEvent(Skillset skillset) throws JsonProcessingException {
	val id = UUID.randomUUID();
	return SkillsetCreatedEvent.builder().uuid(id).skillset(skillset).build();
    }

}
