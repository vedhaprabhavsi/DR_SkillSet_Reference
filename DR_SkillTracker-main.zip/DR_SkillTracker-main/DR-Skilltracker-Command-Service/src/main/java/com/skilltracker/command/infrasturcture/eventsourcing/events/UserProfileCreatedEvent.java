package com.skilltracker.command.infrasturcture.eventsourcing.events;

import com.skilltracker.command.domain.model.UserProfile;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

@Builder
@Data
public class UserProfileCreatedEvent {

    private UUID uuid;

    private UserProfile userProfile;

}
