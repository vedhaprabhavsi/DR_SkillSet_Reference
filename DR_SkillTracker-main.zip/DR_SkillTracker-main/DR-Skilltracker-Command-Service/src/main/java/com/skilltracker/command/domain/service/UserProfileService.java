package com.skilltracker.command.domain.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.skilltracker.command.application.constants.Constants;
import com.skilltracker.command.application.dto.CreateUserProfileRequest;
import com.skilltracker.command.domain.converter.UserProfileConverter;
import com.skilltracker.command.domain.model.UserProfile;
import com.skilltracker.command.infrasturcture.eventsourcing.KafkaUserProfileCreatedEventSourcing;
import com.skilltracker.command.infrasturcture.eventsourcing.events.UserProfileCreatedEvent;
import com.skilltracker.command.infrasturcture.repository.UserProfileRepository;

import lombok.val;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class UserProfileService {

    @Autowired
    private UserProfileConverter userProfileConverter;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private KafkaUserProfileCreatedEventSourcing kafkaUserProfileCreatedEventSourcing;

    public UserProfileCreatedEvent create(CreateUserProfileRequest request) {

	log.info("Creating new userProfile");
	val userProfile = userProfileConverter.createUserProfileRequestRequestToUserProfile(request);
	return createAndPublishProfile(userProfile);
    }

    private UserProfileCreatedEvent createAndPublishProfile(UserProfile userProfile) {
	UserProfileCreatedEvent userProfileCreatedEvent = null;

	try {
	    userProfileRepository.save(userProfile);
	    userProfileCreatedEvent = kafkaUserProfileCreatedEventSourcing.publicCreateUserProfileEvent(userProfile);
	    if (userProfileCreatedEvent == null) {
		userProfile.setPublishStatus(Constants.STATUS_FAILED);
		userProfileRepository.save(userProfile);
	    }
	} catch (JsonProcessingException e) {
	    throw new RuntimeException(e);
	} catch (Exception e) {
	    throw new RuntimeException(e);
	}
	return userProfileCreatedEvent;
    }

    public Optional<UserProfile> findById(Integer userId) {
	return userProfileRepository.findById(userId);
    }

    public UserProfileCreatedEvent updateProfile(UserProfile profile) {
	return createAndPublishProfile(profile);
    }

}
