package com.skilltracker.command.infrasturcture.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.skilltracker.command.domain.model.Skillset;

@Repository
public interface SkillsetRepository extends MongoRepository<Skillset, Integer> {
}
