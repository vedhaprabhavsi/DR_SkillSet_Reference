package com.skilltracker.command.infrasturcture.eventsourcing.events;

import java.util.UUID;

import com.skilltracker.command.domain.model.Skillset;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class SkillsetCreatedEvent {

    private UUID uuid;

    private Skillset skillset;

}
