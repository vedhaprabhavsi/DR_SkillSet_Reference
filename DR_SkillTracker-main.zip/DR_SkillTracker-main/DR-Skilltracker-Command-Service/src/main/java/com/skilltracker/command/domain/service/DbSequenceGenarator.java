package com.skilltracker.command.domain.service;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import com.skilltracker.command.domain.model.DbSequence;

@Service
public class DbSequenceGenarator {

    @Autowired
    private MongoOperations operations;

    public int getNextSequence(final String sequenceName) {
	// Get the sequence number
	final Query q = new Query(Criteria.where("id").is(sequenceName));
	// Increment the sequence number by 1
	// "sequence" should match the attribute value specified in DbSequence.java class.
	final Update u = new Update().inc("sequence", 1);
	// Modify in document
	final DbSequence counter = operations.findAndModify(q, u, FindAndModifyOptions.options().returnNew(true).upsert(true), DbSequence.class);

	return !Objects.isNull(counter) ? counter.getSequence() : 1;
    }

}