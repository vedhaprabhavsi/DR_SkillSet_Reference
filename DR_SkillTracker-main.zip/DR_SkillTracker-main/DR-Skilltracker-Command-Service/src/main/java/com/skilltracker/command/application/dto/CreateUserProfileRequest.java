package com.skilltracker.command.application.dto;

import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateUserProfileRequest {

    @NotBlank(message = "Please enter the Name")
    @NotNull(message = "Please enter the Name")
    @Size(min = 5, message = "Name should be atleast 5 characters")
    @Size(max = 30, message = "Name should not be greater than 30 characters")
    private String name;

    @NotBlank(message = "Please enter the Associate Id")
    @NotNull(message = "Please enter the Associate Id")
    @Pattern(regexp = "^CTS.*$", message = "Associate Id must start with CTS") // , flags =
									       // Pattern.Flag.CASE_INSENSITIVE
    @Size(min = 5, message = "Associate Id should be atleast 5 characters")
    @Size(max = 30, message = "Associate Id should not be greater than 30 characters")
    private String associateId;

    @NotBlank(message = "Please enter the Mobile Number")
    @NotNull(message = "Please enter the Mobile Number")
    @Size(min = 10, max=10, message = "Mobile Number should be exactly 10 characters")
    @Pattern(regexp = "(^$|[0-9]{10})", message = "Mobile Number should be numbers only")
    private String mobile;

    @NotNull(message = "Please enter EMail")
    @NotBlank(message = "Please enter EMail")
    @Email(message = "Please enter valid EMail", regexp = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}")
    private String email;

    private List<String> technicalSkills;

    private List<String> nonTechnicalSkills;

    //private String createdDate;

    private String createdBy;

    //private String updatedDate;

    private String updatedBy;

}
