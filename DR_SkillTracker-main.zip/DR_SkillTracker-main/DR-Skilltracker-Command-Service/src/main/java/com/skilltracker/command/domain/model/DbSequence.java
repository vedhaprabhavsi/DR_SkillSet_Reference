package com.skilltracker.command.domain.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//  Mongodb annotation - marks a class for the domain object that we want to persist in the db
@Document(collection = "DB_SEQUENCE")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
public class DbSequence {

    @Id
    String id;

    @Field("sequence_number")
    int sequence;

}