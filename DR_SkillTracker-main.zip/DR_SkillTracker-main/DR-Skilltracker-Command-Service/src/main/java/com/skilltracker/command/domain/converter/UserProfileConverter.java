package com.skilltracker.command.domain.converter;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.skilltracker.command.application.constants.Constants;
import com.skilltracker.command.application.dto.CreateUserProfileRequest;
import com.skilltracker.command.domain.model.UserProfile;
import com.skilltracker.command.domain.service.DbSequenceGenarator;

@Component
public class UserProfileConverter {

    @Autowired
    private DbSequenceGenarator sequenceGenr;

    public UserProfile createUserProfileRequestRequestToUserProfile(CreateUserProfileRequest req) {
	return UserProfile.builder().id(sequenceGenr.getNextSequence(UserProfile.SEQUENCE_NUMBER)).name(req.getName())
		.associateId(req.getAssociateId()).mobile(req.getMobile()).email(req.getEmail())
		.technicalSkills(req.getTechnicalSkills()).nonTechnicalSkills(req.getNonTechnicalSkills())
		.createdDate(LocalDateTime.now()).updatedDate(LocalDateTime.now())
		.createdBy(req.getCreatedBy()).updatedBy(req.getUpdatedBy())
		.status(Constants.STATUS_A)
		.publishStatus(Constants.STATUS_SUCCESS)
		.build();
    }
}
