package com.skilltracker.command.domain.converter;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.skilltracker.command.application.dto.CreateSkillsetRequest;
import com.skilltracker.command.domain.model.Skillset;
import com.skilltracker.command.domain.service.DbSequenceGenarator;

@Component
public class SkillsetConverter {

    @Autowired
    private DbSequenceGenarator sequenceGenr;

    public Skillset creatSkillsetRequestRequestToSkillset(CreateSkillsetRequest req) {
	return Skillset.builder().skillName(req.getSkillName()).skillType(req.getSkillType())
		.id(sequenceGenr.getNextSequence(Skillset.SEQUENCE_NUMBER)).createdDate(LocalDateTime.now().toString())
		.updatedDate(LocalDateTime.now().toString()).createdBy(req.getCreatedBy()).updatedBy(req.getUpdatedBy())
		.build();
    }

}
