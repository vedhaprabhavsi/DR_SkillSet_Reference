package com.skilltracker.command.domain.model;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Document(value = "USER_PROFILE")
@Data
@Builder
public class UserProfile {

    @Transient
    public static final String SEQUENCE_NUMBER = "userProfile_sequence";

    @Id
    private int id;

    @Indexed(name = "index_name")
    private String name;

    @Indexed(name = "index_associateId")
    private String associateId;

    private String mobile;

    private String email;

    @Indexed(name = "index_technicalSkills")
    private List<String> technicalSkills;

    @Indexed(name = "index_nonTechnicalSkills")
    private List<String> nonTechnicalSkills;

    private String status;

    private LocalDateTime createdDate;

    private String createdBy;

    private LocalDateTime updatedDate;

    private String updatedBy;

    private String publishStatus;

}
