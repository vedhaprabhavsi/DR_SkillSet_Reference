package com.skilltracker.command.domain.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Builder;
import lombok.Data;

@Document(value = "SKILLSET")
@Data
@Builder
@CompoundIndexes({ @CompoundIndex(def = "{'skillName':1, 'skillType':1}", name = "index_compound_skillnametype", unique = true) })
public class Skillset {

    @Transient
    public static final String SEQUENCE_NUMBER = "skillset_sequence";

    @Id
    private int id;

    @Indexed(name = "index_skillName")
    private String skillName;

    @Indexed(name = "index_skillType")
    private String skillType;

    private String createdDate;

    private String createdBy;

    private String updatedDate;

    private String updatedBy;

}
