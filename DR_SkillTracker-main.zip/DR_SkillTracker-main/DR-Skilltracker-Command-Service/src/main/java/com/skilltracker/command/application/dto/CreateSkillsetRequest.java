package com.skilltracker.command.application.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateSkillsetRequest {

    @NotBlank(message = "Please enter the Skill Name")
    @NotNull(message = "Please enter the Skill Name")
    @Size(max = 20, message = "Skill Name should not be greater than 20 characters")
    private String skillName;

    @NotBlank(message = "Please enter the Skill Type (Technical or Non-Technical)")
    @NotNull(message = "Please enter the Skill Type (Technical or Non-Technical)")
    private String skillType;

    private String createdDate;

    private String createdBy;

    private String updatedDate;

    private String updatedBy;

}
