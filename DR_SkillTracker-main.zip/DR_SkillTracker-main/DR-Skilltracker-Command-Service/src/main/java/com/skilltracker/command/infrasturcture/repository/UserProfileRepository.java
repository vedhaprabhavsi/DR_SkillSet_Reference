package com.skilltracker.command.infrasturcture.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.skilltracker.command.domain.model.UserProfile;

@Repository
public interface UserProfileRepository extends MongoRepository<UserProfile, Integer> {

    Optional<UserProfile> findByAssociateId(String userId);

}
