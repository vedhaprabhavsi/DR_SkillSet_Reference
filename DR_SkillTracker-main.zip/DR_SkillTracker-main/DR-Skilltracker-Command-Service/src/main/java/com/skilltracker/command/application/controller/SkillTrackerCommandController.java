package com.skilltracker.command.application.controller;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.skilltracker.command.application.constants.Constants;
import com.skilltracker.command.application.dto.CreateSkillsetRequest;
import com.skilltracker.command.application.dto.CreateUserProfileRequest;
import com.skilltracker.command.domain.exception.InvalidDataException;
import com.skilltracker.command.domain.exception.UserProfileNotFoundException;
import com.skilltracker.command.domain.model.UserProfile;
import com.skilltracker.command.domain.service.SkillsetService;
import com.skilltracker.command.domain.service.UserProfileService;
import com.skilltracker.command.infrasturcture.eventsourcing.events.SkillsetCreatedEvent;
import com.skilltracker.command.infrasturcture.eventsourcing.events.UserProfileCreatedEvent;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/api/v1/engineer")
@CrossOrigin
@Log4j2
public class SkillTrackerCommandController {

    @Autowired
    private UserProfileService userProfileService;

    @Autowired
    private SkillsetService skillsetService;

    @Value("${profileupdate.allowed.days:10}")
    private int profileupdateAllowedDays;

    @PostMapping("/add-profile")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public UserProfileCreatedEvent userProfileCreate(@Valid @RequestBody CreateUserProfileRequest req, HttpServletRequest request) {
	log.info("User profile creation request received for Associate ID[{}]", req.getAssociateId());
	return userProfileService.create(req);
    }

    @PostMapping("/update-profile/{userId}")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public UserProfileCreatedEvent userProfileUpdate(@PathVariable Integer userId, @RequestBody CreateUserProfileRequest req, HttpServletRequest request) {
	Optional<UserProfile> myCustomer = userProfileService.findById(userId);

	if (myCustomer.isPresent()) {
	    log.info("User ID[{}] exists for update process", userId);
	    UserProfile profile = myCustomer.get();
	    Duration dur = Duration.between(profile.getUpdatedDate(), LocalDateTime.now());
	    if (dur.toDays() >= profileupdateAllowedDays) {
		if (!CollectionUtils.isEmpty(req.getTechnicalSkills()) || !CollectionUtils.isEmpty(req.getNonTechnicalSkills())) {

		    if (!CollectionUtils.isEmpty(req.getTechnicalSkills())) {
			profile.setTechnicalSkills(req.getTechnicalSkills());
		    }
		    if (!CollectionUtils.isEmpty(req.getNonTechnicalSkills())) {
			profile.setNonTechnicalSkills(req.getNonTechnicalSkills());
		    }
		    profile.setUpdatedBy(StringUtils.isNotBlank(req.getUpdatedBy()) ? req.getUpdatedBy() : Constants.USER_SYSTEM);
		    profile.setStatus(Constants.STATUS_M);
		    profile.setUpdatedDate(LocalDateTime.now());
		    log.info("Profile update successfully completed for User ID[{}] ", userId);
		    return userProfileService.updateProfile(profile);
		}
	    }
	    log.info("Profile update process failed  for User ID[{}] due to previous updates happened < 10 days", userId);
	    throw new InvalidDataException("Update process can't be proceed due to previous updates happened < 10 days for User ID = " + userId);
	}
	log.info("User ID[{}] not exists for update process", userId);
	throw new UserProfileNotFoundException("Requested user profile not found for User ID = " + userId);

    }

    @PostMapping("/add-skillset")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public SkillsetCreatedEvent skillsetCreate(@Valid @RequestBody CreateSkillsetRequest req, HttpServletRequest request) {
	log.info("Skillset creation request received for skillName[{}]", req.getSkillName());
	return skillsetService.create(req);
    }

}
