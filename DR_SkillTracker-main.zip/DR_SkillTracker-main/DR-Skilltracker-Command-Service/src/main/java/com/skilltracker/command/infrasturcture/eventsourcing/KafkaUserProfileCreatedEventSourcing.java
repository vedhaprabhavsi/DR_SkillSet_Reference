package com.skilltracker.command.infrasturcture.eventsourcing;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.skilltracker.command.domain.model.UserProfile;
import com.skilltracker.command.infrasturcture.eventsourcing.events.UserProfileCreatedEvent;

import lombok.val;
import lombok.extern.log4j.Log4j2;

@Component
@Log4j2
public class KafkaUserProfileCreatedEventSourcing {

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Value(value = "${message.topic.createUserProfile}")
    private String topicName;

    public UserProfileCreatedEvent publicCreateUserProfileEvent(UserProfile userProfile) throws JsonProcessingException {
	val id = UUID.randomUUID();
	ObjectWriter objectWriter = new ObjectMapper().writer().withDefaultPrettyPrinter();
	val json = objectWriter.writeValueAsString(userProfile);
	log.info("Send json '{}' to topic {}", json, topicName);
	try {
	    kafkaTemplate.send(topicName, json);
	} catch (Exception e) {
	    log.error("Exeption while send message to Kafka topic", json, e);
	    return null;
	}
	return UserProfileCreatedEvent.builder().uuid(id).userProfile(userProfile).build();
    }

}
