package com.skilltracker.command.application.constants;

public class Constants {

    public static final String STATUS_A = "A";

    public static final String STATUS_M = "M";

    public static final String USER_SYSTEM = "SYSTEM";

    public static final String STATUS_SUCCESS = "SUCCESS";

    public static final String STATUS_FAILED = "FAILED";

}
