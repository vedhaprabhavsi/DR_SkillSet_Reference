package com.skilltracker.query.domain.service;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skilltracker.query.application.exception.UserProfileNotFoundException;
import com.skilltracker.query.domain.converter.UserProfileConverter;
import com.skilltracker.query.domain.model.UserProfile;
import com.skilltracker.query.infrastructure.repository.UserProfileRepository;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class FindUserProfileService {

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private UserProfileConverter userProfileConverter;

    public Optional<List<UserProfile>> findByCriteriaName(String name, String criteriaValue) throws UserProfileNotFoundException {	
	Optional<List<UserProfile>> userProfile = null;
	if (StringUtils.equalsIgnoreCase(name, "name")) {
	    userProfile = userProfileRepository.findByNameContainingIgnoreCase(criteriaValue);
	}
	else if (StringUtils.equalsIgnoreCase(name, "associateid")) {
	    userProfile = userProfileRepository.findByAssociateIdContainingIgnoreCase(criteriaValue);
	}
	else if (StringUtils.equalsIgnoreCase(name, "technicalskills")) {
	    userProfile = userProfileRepository.findByTechnicalSkillsContainingIgnoreCase(criteriaValue);
	}
	else if (StringUtils.equalsIgnoreCase(name, "nontechnicalskills")) {
	    userProfile = userProfileRepository.findByNonTechnicalSkillsContainingIgnoreCase(criteriaValue);
	}
	log.info("Find userProfile: {}", userProfile);
	return userProfile;
	//return userProfileConverter.userProfileToUserProfileResponse(userProfile);
    }

    public void createUserProfile(UserProfile profile) {
	log.info("Insert new userProfile: {}", profile);
	userProfileRepository.save(profile);
    }

}
