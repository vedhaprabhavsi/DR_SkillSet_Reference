package com.skilltracker.query.application.dto;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserProfileResponse {

    private String id;
    
    private String name;

    private String associateId;

    private String mobile;

    private String email;

    private List<String> technicalSkills;

    private List<String> nonTechnicalSkills;

    private String status;
    
    private LocalDateTime createdDate;

    private String createdBy;

    private LocalDateTime updatedDate;

    private String updatedBy;
    
    private String publishStatus;

}
