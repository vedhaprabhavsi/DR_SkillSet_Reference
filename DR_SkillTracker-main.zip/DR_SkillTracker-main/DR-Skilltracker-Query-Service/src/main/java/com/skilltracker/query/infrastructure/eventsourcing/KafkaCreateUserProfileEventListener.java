package com.skilltracker.query.infrastructure.eventsourcing;

import java.lang.reflect.Type;
import java.time.LocalDateTime;
import java.util.concurrent.CountDownLatch;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.skilltracker.query.domain.model.UserProfile;
import com.skilltracker.query.domain.service.FindUserProfileService;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Component
public class KafkaCreateUserProfileEventListener {

    @Autowired
    private FindUserProfileService findUserProfileService;

    private final CountDownLatch latch = new CountDownLatch(3);
 
    @KafkaListener(topics = "${message.topic.createUserProfile}")
    public void listen(ConsumerRecord<String, String> stringStringConsumerRecord) throws Exception {
	GsonBuilder gsonBuilder = new GsonBuilder();
	gsonBuilder.registerTypeAdapter(LocalDateTime.class, new LocalDateTimeDeserializer());
	Gson gson = gsonBuilder.setPrettyPrinting().create();
	UserProfile userProfile = gson.fromJson(stringStringConsumerRecord.value(), UserProfile.class);
	findUserProfileService.createUserProfile(userProfile);
	log.info("Insert userProfile {} in reader database", userProfile);
	latch.countDown();
    }

} 
 
class LocalDateTimeDeserializer implements JsonDeserializer < LocalDateTime > {
    @Override
    public LocalDateTime deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context)
    throws JsonParseException { 
	JsonObject jo = json.getAsJsonObject();
        return LocalDateTime.of(jo.get("year").getAsInt(),
                jo.get("monthValue").getAsInt(),
                jo.get("dayOfMonth").getAsInt(),
                jo.get("hour").getAsInt(),
                jo.get("minute").getAsInt(),
                jo.get("second").getAsInt(),
                jo.get("nano").getAsInt());
    }
}
