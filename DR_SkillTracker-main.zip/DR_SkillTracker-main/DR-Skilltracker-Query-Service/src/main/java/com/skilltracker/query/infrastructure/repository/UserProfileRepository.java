package com.skilltracker.query.infrastructure.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.skilltracker.query.domain.model.UserProfile;

@Repository
public interface UserProfileRepository extends MongoRepository<UserProfile, Integer> {

    Optional<List<UserProfile>> findByNameContainingIgnoreCase(String name);

    Optional<List<UserProfile>> findByAssociateIdContainingIgnoreCase(String criteriaValue);

    Optional<List<UserProfile>> findByTechnicalSkillsContainingIgnoreCase(String criteriaValue);

    Optional<List<UserProfile>> findByNonTechnicalSkillsContainingIgnoreCase(String criteriaValue);

}
