package com.skilltracker.query.domain.model;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Data;

@Document(value = "USER_PROFILE")
@Data
public class UserProfile {

    @Id
    private String id;

    @Indexed(name = "index_query_name")
    private String name;

    @Indexed(name = "index_query_associateId")
    private String associateId;

    private String mobile;

    private String email;

    @Indexed(name = "index_query_technicalSkills")
    private List<String> technicalSkills;

    @Indexed(name = "index_query_nonTechnicalSkills")
    private List<String> nonTechnicalSkills;
    
    @Indexed(name = "index_query_status")
    private String status;

   private LocalDateTime createdDate;

    private String createdBy;

    private LocalDateTime updatedDate;

    private String updatedBy;
    
//    @Indexed(name = "index_query_publishStatus")
//    private String publishStatus;

    public UserProfile() {
    }

}
