package com.skilltracker.query.domain.converter;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.skilltracker.query.application.dto.UserProfileResponse;
import com.skilltracker.query.domain.model.UserProfile;

@Component
public class UserProfileConverter {

    public UserProfileResponse userProfileToUserProfileResponse(UserProfile req) {
	// Sorting the skill set descending order
	List<String> technicalSkillsList = req.getTechnicalSkills();
	Collections.reverse(technicalSkillsList);
	List<String> nonTechnicalSkillsList = req.getNonTechnicalSkills();
	Collections.reverse(nonTechnicalSkillsList);

	return UserProfileResponse.builder().id(req.getId()).name(req.getName()).associateId(req.getAssociateId())
		.mobile(req.getMobile()).email(req.getEmail())
		.technicalSkills(technicalSkillsList)
		.nonTechnicalSkills(nonTechnicalSkillsList)
		//.createdDate(req.getCreatedDate())
		//.updatedDate(req.getUpdatedDate())
		.createdBy(req.getCreatedBy()).status(req.getStatus())
		.updatedBy(req.getUpdatedBy()).build();
    }

}
