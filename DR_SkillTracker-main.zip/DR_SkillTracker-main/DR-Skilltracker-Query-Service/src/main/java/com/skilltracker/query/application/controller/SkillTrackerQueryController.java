package com.skilltracker.query.application.controller;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skilltracker.query.application.exception.InvalidDataException;
import com.skilltracker.query.application.exception.UserProfileNotFoundException;
import com.skilltracker.query.domain.model.UserProfile;
import com.skilltracker.query.domain.service.FindUserProfileService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("api/v1/admin/")
@CrossOrigin
@Log4j2
public class SkillTrackerQueryController {

    @Autowired
    private FindUserProfileService findUserProfileService;

    @GetMapping("{criteria}/{criteriaValue}")
    public ResponseEntity<?> findUserProfile(@PathVariable String criteria, @PathVariable String criteriaValue) {
	log.info("User profile search query request received for Criteria[{}] , Criteria Value[{}]", criteria, criteriaValue);
	if (StringUtils.isBlank(criteria) || StringUtils.isBlank(criteriaValue)) {
	    log.info("Mandatory criteria field name or value missing");
	    throw new InvalidDataException("Mandatory criteria field name or value missing");
	}
	if (!StringUtils.equalsAnyIgnoreCase(criteria.toLowerCase(), "name", "associateid", "technicalskills", "nontechnicalskills")) {
	    log.info("Invalid criteria name. Expected value - [name, associateid, technicalskills, nontechnicalskills]");
	    throw new InvalidDataException("Invalid criteria name. Expected value - [name, associateid, technicalskills, nontechnicalskills]");
	}
	try {
	    Optional<List<UserProfile>> userProfileResponse = findUserProfileService.findByCriteriaName(criteria.toLowerCase(), criteriaValue);
	    if (userProfileResponse.isPresent() && !CollectionUtils.isEmpty(userProfileResponse.get())) {
		log.info("User profile records available for Criteria[{}] , Criteria Value[{}]", criteria, criteriaValue);
		return new ResponseEntity<>(userProfileResponse.get(), HttpStatus.OK);
	    }
	} catch (Exception ex) {
	    log.error("Exception while seach user profile", ex);
	}
	log.info("User profile not available for given criteria");
	throw new UserProfileNotFoundException("User profile not available for given criteria");
    }

}
