package com.skilltracker.gateway.config;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import com.skilltracker.gateway.exception.ExpiredJwtCustomException;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@RefreshScope
@Component
public class AuthFilter extends AbstractGatewayFilterFactory<AuthFilter.Config> {

    @Autowired
    Environment environment;

    public AuthFilter() {
	super(Config.class);
    }

    public static class Config {
    }

    @Override
    public GatewayFilter apply(Config config) {
	return ((exchange, chain) -> {
	    ServerHttpRequest request = exchange.getRequest();

	    if (!request.getHeaders().containsKey(HttpHeaders.AUTHORIZATION)) {
		throw new ExpiredJwtCustomException("AUTHORIZATION attribute is missing or invalid in request header");
		//return onError(exchange, "No authorization header", HttpStatus.UNAUTHORIZED);
	    }

	    String token = Objects.requireNonNull(request.getHeaders().get(HttpHeaders.AUTHORIZATION)).get(0).replace("Bearer", "");

	    try {
		if (isJwtValid(token))
		    return onError(exchange, "JWT Token is not valid", HttpStatus.UNAUTHORIZED);
	    } catch (ExpiredJwtException e) {
		throw new ExpiredJwtCustomException("JWT Token Expired Already. Please retry with new JWT token", e);
	    }
	    return chain.filter(exchange);
	});
    }

    private Mono<Void> onError(ServerWebExchange exchange, String error, HttpStatus status) {
	ServerHttpResponse response = exchange.getResponse();
	response.setStatusCode(status);
	return response.setComplete();
    }

    /**
     * Validate the JWS token
     * 
     * @param token
     * @return
     */
    private boolean isJwtValid(String token) {
	boolean returnValue = true;
	String subject = null;

	subject = Jwts.parser().setSigningKey(environment.getProperty("token.secret")).parseClaimsJws(token).getBody().getSubject();

	if (subject == null || subject.isEmpty())
	    returnValue = false;
	return returnValue;
    }

}