package com.skilltracker.gateway;

import org.springframework.boot.SpringApplication;
//import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
//import org.springframework.cloud.netflix.zuul.EnableZuulProxy;
import org.springframework.context.annotation.Bean;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import com.skilltracker.gateway.config.AuthFilter;

/**
 * Spring boot application for gateway service
 * 
 */ 
@SpringBootApplication//(exclude = { SecurityAutoConfiguration.class,ManagementWebSecurityAutoConfiguration.class})
//@EnableFeignClients
/*@CrossOrigin
@EnableDiscoveryClient
@EnableZuulProxy*/
@EnableDiscoveryClient
public class GatewayServiceApplication {

	/**
	 * Boot main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(GatewayServiceApplication.class, args);
	}

/*	*//** TODO: This filter is disabled. All the authentication is handled in JWT authentication filter. Might be reused on SSO and LDAP else remove both filter class and bean
	 * Implements the Zuul prefilter
	 * 
	 * @return prefilter instance
	 *//*
	@Bean
	public PreFilter preFilter() {
		return new PreFilter();
	}*/
	
	@Bean
	public CorsFilter corsFilter() {
	    final UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
	    final CorsConfiguration config = new CorsConfiguration();
	    config.setAllowCredentials(true);
	    config.addAllowedOrigin("*");
	    config.addAllowedHeader("*");
	    config.addAllowedMethod("OPTIONS");
	    config.addAllowedMethod("HEAD");
	    config.addAllowedMethod("GET");
	    config.addAllowedMethod("PUT");
	    config.addAllowedMethod("POST");
	    config.addAllowedMethod("DELETE");
	    config.addAllowedMethod("PATCH");
	    source.registerCorsConfiguration("*", config);
	    return new CorsFilter(source);
	}
	
	   /*@Bean
	   public RouteLocator routeLocator(RouteLocatorBuilder rlb, AuthFilter 
	   authorizationHeaderFilter) {

	       return rlb
	               .routes()
	               .route(p -> p
	                   .path("/api/v1/auth")
	                   .filters(f -> f.removeRequestHeader("Cookie")
	                           .rewritePath("/auth-service/(?<segment>.*)", "/$\\{segment}")
	                           .filter(authorizationHeaderFilter.apply(new 
	                        	   AuthFilter.Config())))
	                .uri("lb://auth-service")
	            )
	            .build();
	     }*/

	  /* @Bean
	   public AuthFilter authorizationHeaderFilter() {
	    return new AuthFilter();
	   }*/

}
