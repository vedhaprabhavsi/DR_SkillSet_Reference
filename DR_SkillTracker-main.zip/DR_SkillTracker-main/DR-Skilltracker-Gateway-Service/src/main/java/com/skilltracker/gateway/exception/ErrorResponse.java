package com.skilltracker.gateway.exception;

import java.time.LocalDateTime;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.http.HttpStatus;

import lombok.Data;

@XmlRootElement(name = "error")
@Data
public class ErrorResponse {

    private HttpStatus httpStatus;

    private LocalDateTime timestamp;

    // General error message about nature of error
    private String message;

    // Specific errors in API request processing
    private List<String> details;

    public ErrorResponse(String message, List<String> details) {
	super();
	this.message = message;
	this.details = details;
    }

    public ErrorResponse(String message, List<String> details, HttpStatus httpStatus) {
	this.httpStatus = httpStatus;
	this.timestamp = LocalDateTime.now();
	this.message = message;
	this.details = details;
    }

}