package com.skilltracker.gateway.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
//@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class AuthException extends RuntimeException {

    public AuthException() {
	super();
    }

    public AuthException(String message, Throwable cause) {
	super(message, cause);
    }

    public AuthException(String message) {
	super(message);
    }

}
