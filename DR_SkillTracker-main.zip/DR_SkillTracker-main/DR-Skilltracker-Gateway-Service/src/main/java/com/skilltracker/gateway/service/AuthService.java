package com.skilltracker.gateway.service;

/*import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.skilltracker.gateway.config.FeignConfig;
import com.skilltracker.gateway.model.AuthTokenModel;

@FeignClient(name = "${auth.serviceid}", configuration = FeignConfig.class)
public interface AuthService {

    @GetMapping(value = "/api/v1/auth/generate")
    public AuthTokenModel getJWTToken(@RequestHeader("apikey") String apiKey);

}*/