package com.skilltracker.gateway.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class ExpiredJwtCustomException extends RuntimeException {

    public ExpiredJwtCustomException() {
	super();
    }

    public ExpiredJwtCustomException(String message, Throwable cause) {
	super(message, cause);
    }

    public ExpiredJwtCustomException(String message) {
	super(message);
    }

}
