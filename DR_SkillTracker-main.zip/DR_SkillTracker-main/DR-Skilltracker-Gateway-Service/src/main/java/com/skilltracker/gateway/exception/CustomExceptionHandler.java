package com.skilltracker.gateway.exception;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
 
    /*@ExceptionHandler(AuthException.class)
    public final ResponseEntity<Object> handleAllExceptions(AuthException ex) {
	List<String> details = new ArrayList<>();
	details.add(ex.getLocalizedMessage());
	ErrorResponse error = new ErrorResponse("UnAuthorization Error", details, HttpStatus.UNAUTHORIZED);
	return new ResponseEntity(error, HttpStatus.UNAUTHORIZED);
    }*/

    @ExceptionHandler(ExpiredJwtCustomException.class)
    public final ResponseEntity<Object> handleAllExpiredJwtException(ExpiredJwtCustomException ex) {
	List<String> details = new ArrayList<>();
	details.add(ex.getLocalizedMessage());
	ErrorResponse error = new ErrorResponse("JWT Token Error", details, HttpStatus.UNAUTHORIZED);
	return new ResponseEntity(error, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(NotFoundCustomException.class)
    public final ResponseEntity<Object> handleAllNotFoundCustomException(NotFoundCustomException ex) {
	List<String> details = new ArrayList<>();
	details.add(ex.getLocalizedMessage());
	ErrorResponse error = new ErrorResponse("Service Unavailable Error", details, HttpStatus.SERVICE_UNAVAILABLE);
	return new ResponseEntity(error, HttpStatus.SERVICE_UNAVAILABLE);
    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex) {
	List<String> details = new ArrayList<>();
	details.add(ex.getLocalizedMessage());
	ErrorResponse error = new ErrorResponse("Server Error", details, HttpStatus.INTERNAL_SERVER_ERROR);
	return new ResponseEntity(error, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
