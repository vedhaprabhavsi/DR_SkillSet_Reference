package com.skilltracker.gateway.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
public class NotFoundCustomException extends RuntimeException {

    public NotFoundCustomException() {
	super();
    }

    public NotFoundCustomException(String message, Throwable cause) {
	super(message, cause);
    }

    public NotFoundCustomException(String message) {
	super(message);
    }

}
