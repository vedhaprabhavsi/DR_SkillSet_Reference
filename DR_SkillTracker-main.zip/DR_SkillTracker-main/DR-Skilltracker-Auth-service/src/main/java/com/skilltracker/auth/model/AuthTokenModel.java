package com.skilltracker.auth.model;

import lombok.Data;

@Data
public class AuthTokenModel {

    private String type;

    private String token;

}
