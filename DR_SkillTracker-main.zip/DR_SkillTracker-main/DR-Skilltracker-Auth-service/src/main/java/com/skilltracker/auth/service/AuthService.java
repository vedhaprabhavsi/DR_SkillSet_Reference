package com.skilltracker.auth.service;

import com.skilltracker.auth.model.AuthTokenModel;

public interface AuthService {

    public AuthTokenModel validateApiKeyAndGetJwtToken(String apiKey);

}
