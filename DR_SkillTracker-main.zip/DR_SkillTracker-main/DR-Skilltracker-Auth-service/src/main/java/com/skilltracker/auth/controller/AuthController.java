package com.skilltracker.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.skilltracker.auth.model.AuthTokenModel;
import com.skilltracker.auth.service.AuthService;

import lombok.extern.log4j.Log4j2;

@RestController
@RequestMapping("/api/v1/auth")
@CrossOrigin
@Log4j2
public class AuthController {

    @Autowired
    private AuthService authService;

    @GetMapping(value = "/generate", produces = "application/json")
    public ResponseEntity<AuthTokenModel> getJWTToken(@RequestHeader("apikey") String apiKey) {
	log.info("Auth service request received with api key = {}", apiKey);
	return ResponseEntity.ok(authService.validateApiKeyAndGetJwtToken(apiKey));
    }

}