package com.skilltracker.auth.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.skilltracker.auth.config.PropertySource;
import com.skilltracker.auth.exception.AuthException;
import com.skilltracker.auth.model.AuthTokenModel;
import com.skilltracker.auth.repo.DataStore;
import com.skilltracker.auth.utils.JWTHelper;
import com.skilltracker.auth.utils.TokenClaim;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class AuthServiceImpl implements AuthService {

    @Autowired
    private DataStore dataStore;

    @Autowired
    private PropertySource propertySource;

    @Override
    public AuthTokenModel validateApiKeyAndGetJwtToken(final String apiKey) {
	try {
	    final String userId = validateApiKeyAndGetUserId(apiKey);
	    final Map<String, Object> claims = getUserInfo(userId);
	    final String jwtTokenValue = JWTHelper.createJWT(claims, propertySource.getAppName(), propertySource.getAppAuthSecret(), propertySource.getAppTimeToLive());
	    return getTokenModel(jwtTokenValue);
	} 
	catch (AuthException e) {
	    log.error("AuthException while validate API key and generate JWT token = ",e);
	    throw new AuthException("Unauthorized API key : " + apiKey, e);
	}
	catch (Exception e) {
	    log.error("Exception while validate API key and generate JWT token = ",e);
	    throw new AuthException("Unauthorized API key : " + apiKey, e);
	}
    }

    private final String validateApiKeyAndGetUserId(final String apiKey) {
	return Optional.ofNullable(dataStore.getUserIdForApikey(apiKey)).orElseThrow(() -> new AuthException("InValid API Key"));
    }

    private final Map<String, Object> getUserInfo(final String userId) {
	final Map<String, Object> claims = new HashMap<>();
	final String userInfo = dataStore.getUserInfo(userId);
	final String userRole = dataStore.getUserRole(userId);
	final List<String> authorities = new ArrayList<>();
	authorities.add(userRole);
	claims.put(TokenClaim.USER_ID.getKey(), userId);
	claims.put(TokenClaim.USER_INFO.getKey(), userInfo);
	claims.put(TokenClaim.AUTHORITIES.getKey(), authorities);
	return claims;
    }

    private final AuthTokenModel getTokenModel(final String jwtTokenValue) {
	final AuthTokenModel tokenModel = new AuthTokenModel();
	tokenModel.setType(propertySource.getAppAuthTokenType());
	tokenModel.setToken(jwtTokenValue);
	return tokenModel;
    }

}