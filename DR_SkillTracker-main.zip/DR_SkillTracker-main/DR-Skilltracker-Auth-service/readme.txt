# Need to pass following VM args while startup for fixing the error of "Spring MVC found on classpath, which is incompatible with Spring Cloud Gateway."
spring.main.web-application-type=reactive